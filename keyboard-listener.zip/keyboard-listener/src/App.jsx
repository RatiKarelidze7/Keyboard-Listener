import {useState, useRef, useEffect} from 'react'


function App() {

  const [keyPressed, setKeyPressed] = useState('none');
  const keyCount = useRef({});


  useEffect(() => {

    const keyHandle = (e) => {
      const key = e.key

      if (key in keyCount.current) {
        keyCount.current[key] += 1
      } else {
        keyCount.current[key] = 1
      }

      setKeyPressed(key)
    };

    window.addEventListener('keydown', keyHandle);

    return () => window.removeEventListener('keydown', keyHandle);
  }, []);

  return (
      <div>
        <h1>Keyboard click listener</h1>
        <h3>Last key pressed: {keyPressed}</h3>
        <h4>key count:</h4>
        <pre>{JSON.stringify(keyCount.current, null, 2)}</pre>
      </div>
  );
}


export default App
